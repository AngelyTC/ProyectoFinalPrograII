﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoFinalPrograII
{
    public class SintomasC
    {
        public string CodigoSintoma { get; set; }
        public string DescripcionSintoma { get; set; }
    }
}