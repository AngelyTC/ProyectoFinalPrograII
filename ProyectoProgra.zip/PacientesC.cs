﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoFinalPrograII
{
    public class PacientesC
    {
        public string NITPaciente { get; set; }
        public string NombrePaciente { get; set; }
        public string ApellidoPaciente { get; set; }
        public string DireccionPaciente { get; set; }
        public string FechaNPaciente { get; set; }
        public string TelefonoPaciente { get; set; }
    }
}